package com.aibuddy.client;

import com.aibuddy.AiBuddyConfig;
import com.aibuddy.ai.BuddyMode;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;

/** Opened from the "Config" button in the Mods list on the title screen. */
public class AiBuddyConfigScreen extends Screen {
    private static final int GREY = 0xA0A0A0;

    private static class Opt {
        final String label;
        final String tip;
        boolean value;
        Opt(String label, String tip, boolean value) { this.label = label; this.tip = tip; this.value = value; }
    }

    private final Screen parent;
    private int page = 0;

    private String provider = AiBuddyConfig.PROVIDER.get();
    private String url = AiBuddyConfig.API_URL.get();
    private String key = AiBuddyConfig.API_KEY.get();
    private String model = AiBuddyConfig.MODEL.get();
    private BuddyMode mode = BuddyMode.orGeneral(AiBuddyConfig.MODE.get());
    private boolean showKey = false;
    private String savedNote = "";

    private final Map<String, Opt> opts = new LinkedHashMap<>();

    public AiBuddyConfigScreen(Screen parent) {
        super(Component.literal("AI Buddy Settings"));
        this.parent = parent;
        opts.put("hunger", new Opt("Hunger", "Buddy gets hungry and eats.", AiBuddyConfig.HUNGER.get()));
        opts.put("defend", new Opt("Auto-defend", "Buddy fights nearby hostile mobs on its own.", AiBuddyConfig.AUTO_DEFEND.get()));
        opts.put("armor", new Opt("Auto-wear armor", "Buddy wears the best armor in its inventory.", AiBuddyConfig.AUTO_ARMOR.get()));
        opts.put("duels", new Opt("Allow sparring duels", "Lets the buddy spar with you when you ask (needs server PvP on).", AiBuddyConfig.ALLOW_DUELS.get()));
        // fair play (true = fair)
        opts.put("materials", new Opt("Real materials", "Placing blocks and crafting use items from the buddy's inventory.", AiBuddyConfig.REQUIRE_MATERIALS.get()));
        opts.put("tools", new Opt("Correct tools only", "Stone/ores only drop with the right tool.", AiBuddyConfig.CORRECT_TOOLS.get()));
        opts.put("durability", new Opt("Tools wear out", "Tools and weapons lose durability and break.", AiBuddyConfig.TOOL_DURABILITY.get()));
        opts.put("vision", new Opt("No x-ray", "Only blocks touching air/water are reported or mined.", AiBuddyConfig.FAIR_VISION.get()));
        opts.put("table", new Opt("Crafting table needed", "Recipes bigger than 2x2 need a crafting table nearby.", AiBuddyConfig.CRAFT_TABLE.get()));
        opts.put("support", new Opt("Blocks need support", "No floating blocks: place next to an existing block.", AiBuddyConfig.NEEDS_SUPPORT.get()));
        opts.put("noteleport", new Opt("No teleporting", "Buddy never teleports when stuck.", !AiBuddyConfig.TELEPORT_FALLBACK.get()));
    }

    private static final String[] FAIR_KEYS = {"materials", "tools", "durability", "vision", "table", "support", "noteleport"};

    @Override
    protected void init() {
        int cx = this.width / 2;
        String[] tabs = {"Connection", "Mode", "Fair Play"};
        for (int i = 0; i < tabs.length; i++) {
            final int p = i;
            Button t = Button.builder(Component.literal(tabs[i]), b -> { page = p; rebuildWidgets(); })
                    .bounds(cx - 155 + i * 105, 28, 100, 20).build();
            t.active = page != i;
            addRenderableWidget(t);
        }
        if (page == 0) initConnection(cx);
        else if (page == 1) initMode(cx);
        else initFair(cx);

        addRenderableWidget(Button.builder(Component.literal("Save"), b -> { save(); onClose(); })
                .bounds(cx - 155, this.height - 28, 100, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> onClose())
                .bounds(cx + 55, this.height - 28, 100, 20).build());
    }

    // ------------------------------------------------------------------ pages

    private void initConnection(int cx) {
        Button prov = Button.builder(providerLabel(), b -> {
            provider = provider.equalsIgnoreCase("anthropic") ? "openai" : "anthropic";
            b.setMessage(providerLabel());
        }).bounds(cx - 155, 56, 310, 20).build();
        prov.setTooltip(Tooltip.create(Component.literal("openai = any OpenAI-compatible API (OpenAI, OpenRouter, Ollama...). anthropic = Claude.")));
        addRenderableWidget(prov);

        EditBox urlBox = new EditBox(this.font, cx - 155, 98, 310, 18, Component.literal("API URL"));
        urlBox.setMaxLength(512);
        urlBox.setValue(url);
        urlBox.setHint(Component.literal("empty = default for the provider"));
        urlBox.setResponder(s -> url = s);
        addRenderableWidget(urlBox);

        EditBox keyBox = new EditBox(this.font, cx - 155, 138, 250, 18, Component.literal("API key"));
        keyBox.setMaxLength(512);
        keyBox.setValue(key);
        keyBox.setHint(Component.literal("paste your API key here"));
        keyBox.setFormatter((text, idx) -> FormattedCharSequence.forward(showKey ? text : "*".repeat(text.length()), Style.EMPTY));
        keyBox.setResponder(s -> key = s);
        addRenderableWidget(keyBox);
        addRenderableWidget(Button.builder(Component.literal(showKey ? "Hide" : "Show"), b -> { showKey = !showKey; rebuildWidgets(); })
                .bounds(cx + 100, 137, 55, 20).build());

        EditBox modelBox = new EditBox(this.font, cx - 155, 178, 310, 18, Component.literal("Model"));
        modelBox.setMaxLength(200);
        modelBox.setValue(model);
        modelBox.setHint(Component.literal("e.g. gpt-4o-mini, llama3.1, claude-sonnet-5-5"));
        modelBox.setResponder(s -> model = s);
        addRenderableWidget(modelBox);
    }

    private void initMode(int cx) {
        Button m = Button.builder(modeLabel(), b -> {
            mode = mode.next();
            b.setMessage(modeLabel());
        }).bounds(cx - 155, 56, 310, 20).build();
        m.setTooltip(Tooltip.create(Component.literal("Click to cycle: General, Building Master, PvP Master, Survival Master.")));
        addRenderableWidget(m);

        optButton("hunger", cx - 155, 112, 152);
        optButton("defend", cx + 3, 112, 152);
        optButton("armor", cx - 155, 136, 152);
        optButton("duels", cx + 3, 136, 152);
    }

    private void initFair(int cx) {
        addRenderableWidget(Button.builder(Component.literal("All fair-play ON"), b -> { setFair(true); rebuildWidgets(); })
                .bounds(cx - 155, 56, 152, 20).build());
        addRenderableWidget(Button.builder(Component.literal("All OFF (cheats allowed)"), b -> { setFair(false); rebuildWidgets(); })
                .bounds(cx + 3, 56, 152, 20).build());
        for (int i = 0; i < FAIR_KEYS.length; i++) {
            int col = i % 2;
            int row = i / 2;
            optButton(FAIR_KEYS[i], cx - 155 + col * 158, 90 + row * 24, 152);
        }
    }

    private void setFair(boolean v) {
        for (String k : FAIR_KEYS) opts.get(k).value = v;
    }

    private void optButton(String id, int x, int y, int w) {
        Opt o = opts.get(id);
        Button b = Button.builder(optLabel(o), btn -> {
            o.value = !o.value;
            btn.setMessage(optLabel(o));
        }).bounds(x, y, w, 20).build();
        b.setTooltip(Tooltip.create(Component.literal(o.tip)));
        addRenderableWidget(b);
    }

    private Component optLabel(Opt o) {
        return Component.literal(o.label + ": " + (o.value ? "ON" : "OFF"));
    }

    private Component providerLabel() {
        return Component.literal("Provider: " + provider + (provider.equalsIgnoreCase("anthropic") ? " (Claude)" : " (OpenAI-compatible)"));
    }

    private Component modeLabel() {
        return Component.literal("Mode: " + mode.label);
    }

    // ------------------------------------------------------------------ saving

    private void save() {
        try {
            AiBuddyConfig.PROVIDER.set(provider.trim().toLowerCase());
            AiBuddyConfig.API_URL.set(url.trim());
            AiBuddyConfig.API_KEY.set(key.trim());
            AiBuddyConfig.MODEL.set(model.trim());
            AiBuddyConfig.MODE.set(mode.id);
            AiBuddyConfig.HUNGER.set(opts.get("hunger").value);
            AiBuddyConfig.AUTO_DEFEND.set(opts.get("defend").value);
            AiBuddyConfig.AUTO_ARMOR.set(opts.get("armor").value);
            AiBuddyConfig.ALLOW_DUELS.set(opts.get("duels").value);
            AiBuddyConfig.REQUIRE_MATERIALS.set(opts.get("materials").value);
            AiBuddyConfig.CORRECT_TOOLS.set(opts.get("tools").value);
            AiBuddyConfig.TOOL_DURABILITY.set(opts.get("durability").value);
            AiBuddyConfig.FAIR_VISION.set(opts.get("vision").value);
            AiBuddyConfig.CRAFT_TABLE.set(opts.get("table").value);
            AiBuddyConfig.NEEDS_SUPPORT.set(opts.get("support").value);
            AiBuddyConfig.TELEPORT_FALLBACK.set(!opts.get("noteleport").value);
            AiBuddyConfig.SPEC.save();
        } catch (Exception e) {
            savedNote = "Could not save: " + e.getMessage();
        }
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        g.drawCenteredString(this.font, this.title, this.width / 2, 10, 0xFFFFFF);
        int x = this.width / 2 - 155;
        if (page == 0) {
            g.drawString(this.font, "API URL", x, 86, GREY);
            g.drawString(this.font, "API key (stored as plain text in config/aibuddy-common.toml)", x, 126, GREY);
            g.drawString(this.font, "Model", x, 166, GREY);
            g.drawString(this.font, "Local servers like Ollama need no key.", x, 204, GREY);
        } else if (page == 1) {
            g.drawString(this.font, mode.description, x, 84, 0xFFFFFF);
            g.drawString(this.font, "Applies to buddies without their own mode. Per buddy: /ai mode <mode>", x, 96, GREY);
        } else {
            g.drawString(this.font, "ON = the buddy has to play fair (hover a button for details).", x, 80, GREY);
        }
        if (!savedNote.isEmpty()) {
            g.drawCenteredString(this.font, savedNote, this.width / 2, this.height - 42, 0xFF5555);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) this.minecraft.setScreen(parent);
    }
}
