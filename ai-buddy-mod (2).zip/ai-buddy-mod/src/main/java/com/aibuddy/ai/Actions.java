package com.aibuddy.ai;

import com.aibuddy.AiBuddyConfig;
import com.aibuddy.entity.AiBuddyEntity;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;

/** Everything the buddy can do. The AI's JSON actions are parsed into these. */
public final class Actions {
    private Actions() {}

    private static final Set<String> BANNED = Set.of("bedrock", "barrier", "command_block", "chain_command_block",
            "repeating_command_block", "structure_block", "structure_void", "jigsaw", "light", "end_portal",
            "end_gateway", "nether_portal", "lava", "fire", "soul_fire", "tnt", "moving_piston", "piston_head",
            "spawner", "reinforced_deepslate");

    // =================================================================== base classes

    public abstract static class Action {
        public String result = "done";
        public boolean silent = false;

        public abstract String name();

        /** @return true when finished */
        public abstract boolean tick(AiBuddyEntity b);

        public void onEnd(AiBuddyEntity b) {}

        protected boolean fail(String msg) {
            result = "FAILED - " + msg;
            return true;
        }
    }

    /** Walks toward a block; teleports to a safe spot nearby if stuck. */
    public static class Mover {
        private Vec3 last;
        private int stuck;
        private int total;
        private int teleports;
        public boolean failed;

        public boolean approach(AiBuddyEntity b, BlockPos target, double reach) {
            Vec3 c = Vec3.atCenterOf(target);
            if (b.distanceToSqr(c) <= reach * reach) {
                b.getNavigation().stop();
                return true;
            }
            total++;
            if (total % 10 == 0) {
                Vec3 now = b.position();
                if (last != null && now.distanceToSqr(last) < 0.04D) stuck++;
                else stuck = 0;
                last = now;
            }
            PathNavigation nav = b.getNavigation();
            if (nav.isDone() || total % 20 == 1) {
                nav.moveTo(target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D, 1.15D);
            }
            if (stuck >= 3 || total > 400) {
                stuck = 0;
                total = 0;
                teleports++;
                if (!AiBuddyConfig.TELEPORT_FALLBACK.get() || teleports > 3 || !b.teleportNear(target)) {
                    failed = true;
                }
            }
            return false;
        }
    }

    // =================================================================== simple actions

    public static class Follow extends Action {
        public String name() { return "follow"; }
        public boolean tick(AiBuddyEntity b) { b.setFollowing(true); result = "now following the player"; return true; }
    }

    public static class Stay extends Action {
        public String name() { return "stay"; }
        public boolean tick(AiBuddyEntity b) { b.setFollowing(false); b.getNavigation().stop(); result = "standing still"; return true; }
    }

    public static class Wait extends Action {
        private final int ticks;
        private int age;
        Wait(int ticks) { this.ticks = ticks; }
        public String name() { return "wait"; }
        public boolean tick(AiBuddyEntity b) { return ++age >= ticks; }
    }

    public static class Say extends Action {
        private final String text;
        Say(String text) { this.text = text; }
        public String name() { return "say"; }
        public boolean tick(AiBuddyEntity b) { b.mind.say(text); return true; }
    }

    public static class Come extends Action {
        private final Mover mover = new Mover();
        private int age;
        public String name() { return "come"; }
        public boolean tick(AiBuddyEntity b) {
            Player o = b.getBuddyOwner();
            if (o == null) return fail("player is not in this dimension");
            if (++age > 1200) return fail("took too long");
            if (mover.approach(b, o.blockPosition(), 3.0D)) { result = "arrived next to the player"; return true; }
            if (mover.failed) return fail("could not reach the player");
            return false;
        }
    }

    public static class GoTo extends Action {
        private final BlockPos pos;
        private final Mover mover = new Mover();
        private int age;
        GoTo(BlockPos pos) { this.pos = pos; }
        public String name() { return "goto " + pos.toShortString(); }
        public boolean tick(AiBuddyEntity b) {
            if (++age > 1200) return fail("took too long");
            if (mover.approach(b, pos, 1.8D)) { result = "arrived"; return true; }
            if (mover.failed) return fail("could not reach " + pos.toShortString());
            return false;
        }
    }

    public static class Equip extends Action {
        private final String item;
        Equip(String item) { this.item = item; }
        public String name() { return "equip " + item; }
        public boolean tick(AiBuddyEntity b) {
            if (b.equipByName(item)) result = "holding " + item;
            else return fail("no " + item + " in inventory");
            return true;
        }
    }

    public static class Eat extends Action {
        private final String name;
        private Item item;
        private int age;
        public Eat(String name) { this.name = name; }
        public String getNameArg() { return name; }
        public String name() { return "eat"; }
        public boolean tick(AiBuddyEntity b) {
            if (item == null) {
                item = b.findFoodItem(name);
                if (item == null) return fail("no food in inventory");
                b.setHand(new ItemStack(item));
            }
            age++;
            if (age % 4 == 0) b.swing(InteractionHand.MAIN_HAND);
            if (age >= 32) {
                if (!b.eatOne(item)) return fail("could not eat");
                result = "ate " + BuiltInRegistries.ITEM.getKey(item).getPath() + ", food is now " + b.getFood() + "/20";
                return true;
            }
            return false;
        }
    }

    public static class Craft extends Action {
        private final Item item;
        private final int count;
        Craft(Item item, int count) { this.item = item; this.count = count; }
        public String name() { return "craft " + BuiltInRegistries.ITEM.getKey(item).getPath(); }
        public boolean tick(AiBuddyEntity b) {
            if (!(b.level() instanceof ServerLevel level)) return true;
            List<CraftingRecipe> recipes = level.getRecipeManager().getAllRecipesFor(RecipeType.CRAFTING);
            int made = 0;
            boolean tableNear = nearBlock(b, Blocks.CRAFTING_TABLE, 5);
            boolean needTable = false;
            while (made < count) {
                boolean ok = false;
                for (CraftingRecipe r : recipes) {
                    ItemStack res = r.getResultItem(level.registryAccess());
                    if (res.isEmpty() || !res.is(item)) continue;
                    if (AiBuddyConfig.CRAFT_TABLE.get() && !r.canCraftInDimensions(2, 2) && !tableNear) {
                        needTable = true;
                        continue;
                    }
                    int[] used = b.planIngredients(r.getIngredients());
                    if (used == null) continue;
                    b.consumeUsed(used);
                    b.addToInventory(res.copy());
                    made += res.getCount();
                    ok = true;
                    break;
                }
                if (!ok) break;
            }
            if (made == 0 && needTable) return fail("this recipe needs a crafting table within 5 blocks (place one next to you first)");
            if (made == 0) return fail("missing ingredients or no recipe for " + BuiltInRegistries.ITEM.getKey(item).getPath());
            result = "crafted " + made + " " + BuiltInRegistries.ITEM.getKey(item).getPath();
            return true;
        }
    }

    public static class Give extends Action {
        private final String item;
        private final int count;
        private final Mover mover = new Mover();
        private int age;
        Give(String item, int count) { this.item = item; this.count = count; }
        public String name() { return "give " + item; }
        public boolean tick(AiBuddyEntity b) {
            Player o = b.getBuddyOwner();
            if (o == null) return fail("player is not in this dimension");
            if (++age > 1200) return fail("took too long");
            if (!mover.approach(b, o.blockPosition(), 2.5D)) {
                return mover.failed && fail("could not reach the player");
            }
            int given = 0;
            if (item.equals("all")) {
                for (int i = 0; i < b.getBuddyInventory().getContainerSize(); i++) {
                    ItemStack s = b.getBuddyInventory().getItem(i);
                    if (s.isEmpty()) continue;
                    given += s.getCount();
                    toss(b, o, s.copy());
                    b.getBuddyInventory().setItem(i, ItemStack.EMPTY);
                }
            } else {
                Item it = item(item);
                ItemStack removed = b.removeItem(it, count);
                if (!removed.isEmpty()) { given = removed.getCount(); toss(b, o, removed); }
            }
            if (given == 0) return fail("had nothing to give");
            result = "gave " + given + " items to the player";
            return true;
        }
        private static void toss(AiBuddyEntity b, Player o, ItemStack stack) {
            ItemEntity ie = new ItemEntity(b.level(), b.getX(), b.getEyeY() - 0.3D, b.getZ(), stack);
            Vec3 dir = o.position().subtract(b.position()).normalize().scale(0.25D);
            ie.setDeltaMovement(dir.x, 0.2D, dir.z);
            ie.setPickUpDelay(20);
            ie.getPersistentData().putBoolean("aibuddy_given", true);
            b.level().addFreshEntity(ie);
        }
    }

    public static class Collect extends Action {
        private ItemEntity target;
        private Mover mover = new Mover();
        private final Set<Integer> skip = new HashSet<>();
        private int age;
        private int got;
        public String name() { return "collect"; }
        public boolean tick(AiBuddyEntity b) {
            if (++age > 800) { result = "collected " + got + " stacks (timed out)"; return true; }
            if (target == null || target.isRemoved()) {
                if (target != null && target.isRemoved()) got++;
                target = null;
                double bd = Double.MAX_VALUE;
                for (ItemEntity ie : b.level().getEntitiesOfClass(ItemEntity.class, b.getBoundingBox().inflate(20.0D),
                        e -> !e.getPersistentData().getBoolean("aibuddy_given") && !skip.contains(e.getId()))) {
                    double d = b.distanceToSqr(ie);
                    if (d < bd) { bd = d; target = ie; }
                }
                mover = new Mover();
                if (target == null) {
                    result = got > 0 ? "collected " + got + " item stacks" : "no dropped items nearby";
                    return true;
                }
            }
            if (mover.approach(b, target.blockPosition(), 1.2D)) return false; // pickup happens automatically
            if (mover.failed) { skip.add(target.getId()); target = null; }
            return false;
        }
    }

    public static class Attack extends Action {
        private final String want;
        private final boolean hostile;
        private final int maxKills;
        private LivingEntity victim;
        private int kills;
        private int age;
        private int cooldown;
        public Attack(String target, int maxKills) {
            this.want = target.toLowerCase(Locale.ROOT).replace("minecraft:", "");
            this.hostile = want.equals("nearest_hostile") || want.equals("hostile");
            this.maxKills = maxKills;
        }
        public String name() { return "attack " + want; }
        public boolean tick(AiBuddyEntity b) {
            if (++age > 600) { result = "defeated " + kills + " (timed out)"; return true; }
            if (victim != null && !victim.isAlive()) { kills++; victim = null; }
            if (kills >= maxKills) { result = "defeated " + kills; return true; }
            if (victim == null) {
                victim = find(b);
                if (victim == null) {
                    if (kills > 0) { result = "defeated " + kills; return true; }
                    return fail("no '" + want + "' nearby");
                }
                b.equipBestWeapon();
            }
            if (b.distanceToSqr(victim) > 6.0D) {
                if (b.tickCount % 5 == 0 || b.getNavigation().isDone()) b.getNavigation().moveTo(victim, 1.3D);
            } else {
                b.getNavigation().stop();
                b.getLookControl().setLookAt(victim, 30.0F, 30.0F);
                if (--cooldown <= 0) {
                    b.swing(InteractionHand.MAIN_HAND);
                    b.doHurtTarget(victim);
                    b.damageHeldTool();
                    cooldown = attackInterval(b);
                }
            }
            return false;
        }
        private LivingEntity find(AiBuddyEntity b) {
            LivingEntity best = null;
            double bd = Double.MAX_VALUE;
            for (LivingEntity e : b.level().getEntitiesOfClass(LivingEntity.class, b.getBoundingBox().inflate(24.0D), x -> {
                if (x == b || !x.isAlive() || x instanceof Player || x instanceof AiBuddyEntity) return false;
                if (hostile) return AiBuddyEntity.isValidHostile(x);
                return BuiltInRegistries.ENTITY_TYPE.getKey(x.getType()).getPath().contains(want);
            })) {
                double d = b.distanceToSqr(e);
                if (d < bd) { bd = d; best = e; }
            }
            return best;
        }
        @Override public void onEnd(AiBuddyEntity b) { b.getNavigation().stop(); }
    }

    /** Ticks between swings, from the held weapon's attack speed (like the vanilla attack cooldown). */
    static int attackInterval(AiBuddyEntity b) {
        double speed = 4.0D;
        for (var mod : b.getMainHandItem().getAttributeModifiers(net.minecraft.world.entity.EquipmentSlot.MAINHAND)
                .get(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_SPEED)) {
            speed += mod.getAmount();
        }
        return (int) Math.ceil(20.0D / Math.max(0.5D, speed));
    }

    public static class Duel extends Action {
        private int age;
        private int cooldown;
        private boolean armed;
        public String name() { return "duel"; }
        public boolean tick(AiBuddyEntity b) {
            if (!AiBuddyConfig.ALLOW_DUELS.get()) return fail("duels are disabled (config allowDuels=false)");
            Player o = b.getBuddyOwner();
            if (o == null) return fail("player is not in this dimension");
            if (b.getServer() == null || !b.getServer().isPvpAllowed()) return fail("PvP is disabled on this server");
            if (++age > 1200) { result = "duel timed out"; return true; }
            if (o.getHealth() <= 6.0F) { b.mind.say("gg! You're low, I'll stop."); result = "duel over: spared the player (low health)"; return true; }
            if (b.getHealth() <= 5.0F) { b.mind.say("Okay okay, I yield!"); result = "duel over: I was low on health"; return true; }
            if (!armed) { b.equipBestWeapon(); armed = true; }
            if (b.distanceToSqr(o) > 6.0D) {
                if (b.tickCount % 5 == 0 || b.getNavigation().isDone()) b.getNavigation().moveTo(o, 1.3D);
            } else {
                b.getNavigation().stop();
                b.getLookControl().setLookAt(o, 30.0F, 30.0F);
                if (--cooldown <= 0) {
                    b.swing(InteractionHand.MAIN_HAND);
                    b.doHurtTarget(o);
                    b.damageHeldTool();
                    cooldown = attackInterval(b);
                }
            }
            return false;
        }
        @Override public void onEnd(AiBuddyEntity b) { b.getNavigation().stop(); }
    }

    // =================================================================== right click / smelting

    /** Right-click a block (door, lever, button, trapdoor...) or use an item on it (oriented placing, seeds, hoe, bone meal...). */
    public static class Use extends Action {
        private final BlockPos pos;
        private final Direction face;
        private final String itemName;
        private final Direction look;
        private final Mover mover = new Mover();
        private int age;
        Use(BlockPos pos, Direction face, String itemName, Direction look) {
            this.pos = pos; this.face = face; this.itemName = itemName; this.look = look;
        }
        public String name() { return "use " + pos.toShortString() + (itemName != null ? " with " + itemName : ""); }
        public boolean tick(AiBuddyEntity b) {
            if (++age > 600) return fail("took too long");
            if (!mover.approach(b, pos, 4.5D)) {
                return mover.failed && fail("cannot reach " + pos.toShortString());
            }
            ItemStack stack = ItemStack.EMPTY;
            if (itemName != null) {
                Item it = item(itemName);
                if (b.isSurvivalRules()) {
                    stack = b.findStack(it);
                    if (stack == null) return fail("no " + itemName + " in inventory");
                } else {
                    stack = new ItemStack(it);
                }
            }
            b.getLookControl().setLookAt(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);
            b.swing(InteractionHand.MAIN_HAND);
            InteractionResult r = b.rightClick(pos, face, stack, look);
            if (!r.consumesAction()) return fail("nothing happened (that block/item can't be used that way here)");
            result = "used " + (itemName != null ? itemName : "hand") + " on " + pos.toShortString() + " face " + face.getName();
            return true;
        }
    }

    /** Smelts items in the buddy's inventory; needs a furnace within reach and fuel. */
    public static class Smelt extends Action {
        private final Item input;
        private final int count;
        private BlockPos furnace;
        private final Mover mover = new Mover();
        private int done;
        private int timer;
        private int fuelLeft;
        private ItemStack pending = ItemStack.EMPTY;
        private int age;
        Smelt(Item input, int count) { this.input = input; this.count = count; }
        public String name() { return "smelt " + BuiltInRegistries.ITEM.getKey(input).getPath(); }
        public boolean tick(AiBuddyEntity b) {
            Level level = b.level();
            if (++age > 20 * 60 * 6) return fail("timed out after smelting " + done);
            if (furnace == null) {
                furnace = findBlock(b, Blocks.FURNACE, 12);
                if (furnace == null) return fail("no furnace within 12 blocks (craft one from 8 cobblestone and place it)");
            }
            if (!level.getBlockState(furnace).is(Blocks.FURNACE)) return fail("the furnace disappeared");
            if (!mover.approach(b, furnace, 3.0D)) {
                return mover.failed && fail("cannot reach the furnace");
            }
            b.getLookControl().setLookAt(furnace.getX() + 0.5D, furnace.getY() + 0.5D, furnace.getZ() + 0.5D);
            if (timer > 0) {
                timer--;
                if (timer % 20 == 0) b.swing(InteractionHand.MAIN_HAND);
                if (timer == 0) {
                    b.addToInventory(pending);
                    pending = ItemStack.EMPTY;
                    done++;
                }
                return false;
            }
            if (done >= count) { result = "smelted " + done + " " + BuiltInRegistries.ITEM.getKey(input).getPath(); return true; }
            ItemStack in = b.findStack(input);
            if (in == null) {
                if (done > 0) { result = "smelted " + done + " (ran out of input)"; return true; }
                return fail("no " + BuiltInRegistries.ITEM.getKey(input).getPath() + " in inventory");
            }
            Optional<SmeltingRecipe> rec = level.getRecipeManager().getRecipeFor(RecipeType.SMELTING, new SimpleContainer(in.copy()), level);
            if (rec.isEmpty()) return fail("that item cannot be smelted");
            int cook = rec.get().getCookingTime();
            if (fuelLeft < cook) {
                boolean found = false;
                for (int i = 0; i < b.getBuddyInventory().getContainerSize(); i++) {
                    ItemStack s = b.getBuddyInventory().getItem(i);
                    if (s.isEmpty() || s.is(input) || s.hasCraftingRemainingItem()) continue;
                    int burn = net.minecraftforge.common.ForgeHooks.getBurnTime(s, RecipeType.SMELTING);
                    if (burn > 0) { s.shrink(1); fuelLeft += burn; found = true; break; }
                }
                if (!found) {
                    if (done > 0) { result = "smelted " + done + " (out of fuel)"; return true; }
                    return fail("no fuel (coal, charcoal, planks, logs...) in inventory");
                }
            }
            fuelLeft -= cook;
            in.shrink(1);
            pending = rec.get().getResultItem(level.registryAccess()).copy();
            timer = cook;
            return false;
        }
    }

    static boolean nearBlock(AiBuddyEntity b, Block block, int r) {
        return findBlock(b, block, r) != null;
    }

    static BlockPos findBlock(AiBuddyEntity b, Block block, int r) {
        Level level = b.level();
        BlockPos c = b.blockPosition();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r / 2; dy <= r / 2; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    mp.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    if (!level.isLoaded(mp)) continue;
                    if (level.getBlockState(mp).is(block)) {
                        double d = dx * dx + dy * dy + dz * dz;
                        if (d < bd) { bd = d; best = mp.immutable(); }
                    }
                }
            }
        }
        return best;
    }

    // =================================================================== mining

    public static class Mine extends Action {
        private final String want;
        private final boolean exact;
        private final int count;
        private final BlockPos fixed;
        private BlockPos target;
        private Mover mover = new Mover();
        private int mined;
        private int progress;
        private int needed;
        private int age;

        Mine(String want, int count, BlockPos fixed) {
            this.want = want == null ? "" : want.toLowerCase(Locale.ROOT).replace("minecraft:", "");
            ResourceLocation rl = ResourceLocation.tryParse("minecraft:" + this.want);
            this.exact = rl != null && BuiltInRegistries.BLOCK.containsKey(rl);
            this.count = count;
            this.fixed = fixed;
        }

        public String name() { return fixed != null ? "break " + fixed.toShortString() : "mine " + want; }

        private boolean matches(BlockState s) {
            String path = BuiltInRegistries.BLOCK.getKey(s.getBlock()).getPath();
            return exact ? path.equals(want) : path.contains(want);
        }

        public boolean tick(AiBuddyEntity b) {
            Level level = b.level();
            if (mined >= count) { result = "mined " + mined + (fixed != null ? " block" : " " + want); return true; }
            if (++age > 20 * 60 * 5) return fail("timed out after mining " + mined);

            if (target == null) {
                if (fixed != null) {
                    if (level.getBlockState(fixed).isAir()) {
                        if (mined > 0) { result = "done"; return true; }
                        return fail("there is no block at " + fixed.toShortString());
                    }
                    target = fixed;
                } else {
                    target = findNearest(b);
                    if (target == null) {
                        if (mined > 0) { result = "mined " + mined + " " + want + " (no more nearby)"; return true; }
                        return fail("no '" + want + "' found within " + AiBuddyConfig.MINE_RADIUS.get() + " blocks"
                                + (AiBuddyConfig.FAIR_VISION.get() ? " (only visible/exposed blocks count: explore or dig to find more)" : ""));
                    }
                }
                progress = 0;
                mover = new Mover();
            }

            BlockState st = level.getBlockState(target);
            if (st.isAir() || (fixed == null && !matches(st))) {
                level.destroyBlockProgress(b.getId(), target, -1);
                if (fixed != null) { mined++; }
                target = null;
                return false;
            }
            float hard = st.getDestroySpeed(level, target);
            if (hard < 0) return fail("that block is unbreakable");
            if (!AiBuddyConfig.BREAK_CONTAINERS.get() && level.getBlockEntity(target) != null) {
                return fail("refusing to break a container/special block (config breakContainers=false)");
            }

            if (!mover.approach(b, target, 4.0D)) {
                if (mover.failed) return fail("cannot reach the block at " + target.toShortString());
                return false;
            }

            b.getLookControl().setLookAt(target.getX() + 0.5D, target.getY() + 0.5D, target.getZ() + 0.5D);
            if (progress == 0) {
                b.equipBestTool(st);
                ItemStack tool = b.getMainHandItem();
                float speed = tool.getDestroySpeed(st);
                boolean harvest = !st.requiresCorrectToolForDrops() || tool.isCorrectToolForDrops(st);
                float perTick = speed / hard / (harvest ? 30.0F : 100.0F);
                needed = (int) Math.ceil(1.0F / perTick);
                if (perTick <= 0 || Float.isInfinite(perTick)) needed = 3;
                needed = Math.max(3, Math.min(300, needed));
            }
            progress++;
            if (progress % 5 == 1) b.swing(InteractionHand.MAIN_HAND);
            if (progress % 4 == 0) {
                level.playSound(null, target, st.getSoundType().getHitSound(), SoundSource.BLOCKS, 0.6F, 0.9F);
            }
            level.destroyBlockProgress(b.getId(), target, Math.min(9, progress * 10 / needed));
            if (progress >= needed) {
                level.destroyBlockProgress(b.getId(), target, -1);
                b.mineBlock(target);
                mined++;
                target = null;
            }
            return false;
        }

        @Override
        public void onEnd(AiBuddyEntity b) {
            if (target != null) b.level().destroyBlockProgress(b.getId(), target, -1);
            b.getNavigation().stop();
        }

        private BlockPos findNearest(AiBuddyEntity b) {
            Level level = b.level();
            BlockPos c = b.blockPosition();
            int r = AiBuddyConfig.MINE_RADIUS.get();
            boolean fair = AiBuddyConfig.FAIR_VISION.get();
            BlockPos bestExposed = null;
            BlockPos bestAny = null;
            double be = Double.MAX_VALUE;
            double ba = Double.MAX_VALUE;
            BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        mp.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                        if (!level.isLoaded(mp)) continue;
                        BlockState s = level.getBlockState(mp);
                        if (s.isAir() || !matches(s)) continue;
                        if (s.getDestroySpeed(level, mp) < 0) continue;
                        double d = dx * dx + dy * dy + dz * dz;
                        boolean exposed = isExposed(level, mp);
                        if (fair && !exposed) continue;
                        if (d < ba) { ba = d; bestAny = mp.immutable(); }
                        if (d < be && exposed) { be = d; bestExposed = mp.immutable(); }
                    }
                }
            }
            return bestExposed != null ? bestExposed : bestAny;
        }

        private static boolean isExposed(Level level, BlockPos pos) {
            for (net.minecraft.core.Direction d : net.minecraft.core.Direction.values()) {
                BlockPos n = pos.relative(d);
                if (level.getBlockState(n).getCollisionShape(level, n).isEmpty()) return true;
            }
            return false;
        }
    }

    // =================================================================== building

    public static class Build extends Action {
        private final Block block;
        private final List<BlockPos> cells;
        private final boolean force;
        private final String label;
        private final boolean clearing;
        private Mover mover = new Mover();
        private int i;
        private int placed;
        private int skipped;
        private int blocked;
        private int age;
        private final Set<BlockPos> deferred = new HashSet<>();

        Build(Block block, List<BlockPos> cells, boolean force) {
            this.block = block;
            this.cells = cells;
            this.force = force;
            this.clearing = block == Blocks.AIR;
            this.label = BuiltInRegistries.BLOCK.getKey(block).getPath();
        }

        public String name() { return (clearing ? "clear " : "build ") + label + " (" + cells.size() + " blocks)"; }

        public boolean tick(AiBuddyEntity b) {
            Level level = b.level();
            if (++age > 20 * 60 * 20) return fail("timed out after placing " + placed);
            int budget = 64;
            while (i < cells.size() && budget-- > 0) {
                BlockPos pos = cells.get(i);
                BlockState cur = level.getBlockState(pos);

                if (cur.getBlock() == block) { i++; continue; }
                if (clearing) {
                    if (cur.isAir()) { i++; continue; }
                } else if (!force && !(cur.isAir() || cur.canBeReplaced())) {
                    skipped++; i++; continue;
                }
                if (cur.getDestroySpeed(level, pos) < 0 || !level.isLoaded(pos)) { skipped++; i++; continue; }
                if (!clearing && AiBuddyConfig.NEEDS_SUPPORT.get() && !supported(level, pos)) {
                    // no floating blocks: try again later (once), after neighbours exist
                    if (deferred.add(pos)) cells.add(pos);
                    else skipped++;
                    i++;
                    continue;
                }

                if (!mover.approach(b, pos, 4.5D)) {
                    if (mover.failed) { skipped++; i++; mover = new Mover(); }
                    return false;
                }
                if (b.tickCount % AiBuddyConfig.BUILD_DELAY.get() != 0) return false;

                b.getLookControl().setLookAt(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);
                BlockState ns = block.defaultBlockState();

                if (clearing) {
                    b.clearBlock(pos);
                } else {
                    if (!level.isUnobstructed(ns, pos, CollisionContext.empty())) {
                        if (b.getBoundingBox().intersects(new AABB(pos))) b.teleportNear(pos);
                        if (++blocked > 60) { skipped++; i++; blocked = 0; }
                        return false;
                    }
                    if (b.isSurvivalRules()) {
                        Item it = block.asItem();
                        if (it == net.minecraft.world.item.Items.AIR || b.countItem(it) < 1) {
                            return fail("ran out of " + label + " after placing " + placed + " (survival mode: mine or craft more)");
                        }
                        b.removeItem(it, 1);
                    }
                    place(level, pos, ns);
                }
                blocked = 0;
                b.swing(InteractionHand.MAIN_HAND);
                placed++;
                i++;
                return false;
            }
            if (i >= cells.size()) {
                result = (clearing ? "cleared " : "placed ") + placed + " " + label
                        + (skipped > 0 ? " (skipped " + skipped + " occupied/unreachable cells)" : "");
                return true;
            }
            return false;
        }

        private static boolean supported(Level level, BlockPos pos) {
            for (Direction d : Direction.values()) {
                BlockState s = level.getBlockState(pos.relative(d));
                if (!s.isAir() && !s.canBeReplaced()) return true;
            }
            return false;
        }

        private void place(Level level, BlockPos pos, BlockState ns) {
            if (block instanceof DoorBlock) {
                level.setBlock(pos, ns.setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER), 3);
                level.setBlock(pos.above(), ns.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER), 3);
            } else {
                level.setBlock(pos, Block.updateFromNeighbourShapes(ns, level, pos), 3);
            }
            level.playSound(null, pos, ns.getSoundType().getPlaceSound(), SoundSource.BLOCKS, 1.0F, 1.0F);
        }
    }

    // =================================================================== parsing

    public static List<Action> parseAll(JsonArray arr, AiBuddyEntity b, ServerPlayer player, List<String> errors) {
        List<Action> out = new ArrayList<>();
        int max = AiBuddyConfig.MAX_ACTIONS.get();
        for (JsonElement el : arr) {
            if (out.size() >= max) { errors.add("too many actions in one reply; ignored the rest"); break; }
            if (!el.isJsonObject()) continue;
            try {
                Action a = parse(el.getAsJsonObject(), b, player);
                if (a != null) out.add(a);
            } catch (Exception e) {
                errors.add("bad action " + el + ": " + e.getMessage());
            }
        }
        return out;
    }

    private static Action parse(JsonObject o, AiBuddyEntity b, ServerPlayer p) {
        String type = str(o, "type", "").toLowerCase(Locale.ROOT).trim();
        BlockPos origin = BlockPos.ZERO;
        String rel = str(o, "rel", "");
        if (rel.equals("player") && p != null) origin = p.blockPosition();
        else if (rel.equals("buddy")) origin = b.blockPosition();

        switch (type) {
            case "follow": return new Follow();
            case "stay": case "stop": return new Stay();
            case "come": return new Come();
            case "goto": case "go_to": case "move": case "move_to":
                return new GoTo(pos(o, origin, "x", "y", "z"));
            case "mine": {
                String blk = str(o, "block", "");
                if (blk.isBlank()) throw new IllegalArgumentException("mine needs a 'block'");
                return new Mine(blk, clamp(intOr(o, "count", 1), 1, 256), null);
            }
            case "break":
                return new Mine(null, 1, pos(o, origin, "x", "y", "z"));
            case "collect": return new Collect();
            case "place": {
                Block blk = block(str(o, "block", ""));
                BlockPos at = pos(o, origin, "x", "y", "z");
                List<BlockPos> cells = new ArrayList<>();
                cells.add(at);
                return new Build(blk, cells, bool(o, "force"));
            }
            case "fill": {
                Block blk = block(str(o, "block", ""));
                BlockPos a = pos(o, origin, "x1", "y1", "z1");
                BlockPos c = pos(o, origin, "x2", "y2", "z2");
                String mode = str(o, "mode", "solid").toLowerCase(Locale.ROOT);
                return new Build(blk, cells(a, c, mode), bool(o, "force"));
            }
            case "use": case "right_click": {
                BlockPos at = pos(o, origin, "x", "y", "z");
                Direction face = Direction.byName(str(o, "face", "up").toLowerCase(Locale.ROOT));
                if (face == null) throw new IllegalArgumentException("bad 'face' (use up, down, north, south, east, west)");
                Direction look = o.has("look") ? Direction.byName(str(o, "look", "").toLowerCase(Locale.ROOT)) : null;
                return new Use(at, face, o.has("item") ? str(o, "item", null) : null, look);
            }
            case "smelt": return new Smelt(item(str(o, "item", "")), clamp(intOr(o, "count", 1), 1, 64));
            case "duel": return new Duel();
            case "craft": return new Craft(item(str(o, "item", "")), clamp(intOr(o, "count", 1), 1, 256));
            case "eat": return new Eat(o.has("item") ? str(o, "item", null) : null);
            case "equip": return new Equip(str(o, "item", ""));
            case "attack": {
                String tg = str(o, "target", "nearest_hostile");
                boolean hostile = tg.equals("nearest_hostile") || tg.equals("hostile");
                return new Attack(tg, clamp(intOr(o, "count", hostile ? 99 : 1), 1, 99));
            }
            case "give": return new Give(str(o, "item", "all").toLowerCase(Locale.ROOT), clamp(intOr(o, "count", 64), 1, 2304));
            case "wait": return new Wait(clamp(intOr(o, "ticks", 20), 1, 1200));
            case "say": return new Say(str(o, "text", ""));
            default: throw new IllegalArgumentException("unknown action type '" + type + "'");
        }
    }

    private static List<BlockPos> cells(BlockPos a, BlockPos b, String mode) {
        int x1 = Math.min(a.getX(), b.getX()), x2 = Math.max(a.getX(), b.getX());
        int y1 = Math.min(a.getY(), b.getY()), y2 = Math.max(a.getY(), b.getY());
        int z1 = Math.min(a.getZ(), b.getZ()), z2 = Math.max(a.getZ(), b.getZ());
        long vol = (long) (x2 - x1 + 1) * (y2 - y1 + 1) * (z2 - z1 + 1);
        if (vol > 250_000L) throw new IllegalArgumentException("fill region is far too large (" + vol + " blocks)");
        List<BlockPos> out = new ArrayList<>();
        for (int y = y1; y <= y2; y++) {
            for (int xi = 0; xi <= x2 - x1; xi++) {
                int x = x1 + xi;
                for (int zi = 0; zi <= z2 - z1; zi++) {
                    int z = (xi % 2 == 0) ? z1 + zi : z2 - zi; // snake order = less walking
                    boolean ex = x == x1 || x == x2, ey = y == y1 || y == y2, ez = z == z1 || z == z2;
                    boolean inc;
                    switch (mode) {
                        case "hollow": inc = ex || ey || ez; break;
                        case "walls": inc = ex || ez; break;
                        case "outline": inc = (ex ? 1 : 0) + (ey ? 1 : 0) + (ez ? 1 : 0) >= 2; break;
                        default: inc = true;
                    }
                    if (inc) out.add(new BlockPos(x, y, z));
                }
            }
        }
        int max = AiBuddyConfig.MAX_BUILD_BLOCKS.get();
        if (out.size() > max) throw new IllegalArgumentException("fill too large (" + out.size() + " blocks, max " + max + ")");
        return out;
    }

    // =================================================================== helpers

    private static String str(JsonObject o, String k, String def) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : def;
    }

    private static boolean bool(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() && o.get(k).getAsBoolean();
    }

    private static int num(JsonObject o, String k) {
        if (!o.has(k) || o.get(k).isJsonNull()) throw new IllegalArgumentException("missing '" + k + "'");
        return (int) Math.floor(o.get(k).getAsDouble());
    }

    private static int intOr(JsonObject o, String k, int def) {
        return o.has(k) && !o.get(k).isJsonNull() ? (int) Math.floor(o.get(k).getAsDouble()) : def;
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private static BlockPos pos(JsonObject o, BlockPos origin, String kx, String ky, String kz) {
        return new BlockPos(origin.getX() + num(o, kx), origin.getY() + num(o, ky), origin.getZ() + num(o, kz));
    }

    private static ResourceLocation rl(String id) {
        String s = id.trim().toLowerCase(Locale.ROOT);
        ResourceLocation r = ResourceLocation.tryParse(s.contains(":") ? s : "minecraft:" + s);
        if (r == null) throw new IllegalArgumentException("invalid id '" + id + "'");
        return r;
    }

    static Block block(String id) {
        ResourceLocation r = rl(id);
        if (!BuiltInRegistries.BLOCK.containsKey(r)) throw new IllegalArgumentException("unknown block '" + id + "'");
        String path = r.getPath();
        if (BANNED.contains(path) || path.endsWith("_bed") || path.contains("command_block")) {
            throw new IllegalArgumentException("block '" + id + "' is not allowed");
        }
        return BuiltInRegistries.BLOCK.get(r);
    }

    static Item item(String id) {
        ResourceLocation r = rl(id);
        if (!BuiltInRegistries.ITEM.containsKey(r)) throw new IllegalArgumentException("unknown item '" + id + "'");
        return BuiltInRegistries.ITEM.get(r);
    }
}
