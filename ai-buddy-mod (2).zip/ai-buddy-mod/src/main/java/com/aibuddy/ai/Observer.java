package com.aibuddy.ai;

import com.aibuddy.AiBuddyConfig;
import com.aibuddy.entity.AiBuddyEntity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/** Turns the world around the buddy into text the AI can read. */
public final class Observer {
    private static final String[] INTERESTING = {"ore", "log", "chest", "crafting", "furnace", "bed", "water", "lava",
            "door", "spawner", "ancient", "wheat", "carrots", "potatoes", "sugar_cane", "pumpkin", "melon", "barrel", "anvil"};

    private Observer() {}

    public static String fmt(BlockPos p) {
        return p.getX() + "," + p.getY() + "," + p.getZ();
    }

    public static String itemId(ItemStack s) {
        return s.isEmpty() ? "nothing" : BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
    }

    public static String observe(AiBuddyEntity b, ServerPlayer p) {
        Level level = b.level();
        BlockPos bp = b.blockPosition();
        StringBuilder sb = new StringBuilder("STATE:\n");

        sb.append("BUDDY_MODE: ").append(b.getMode().label).append('\n');
        sb.append("MATERIALS: ").append(b.isSurvivalRules()
                ? "survival (placing blocks and crafting use items from your inventory)"
                : "free-building (placing blocks costs nothing; mining still gives you items)").append('\n');

        long t = level.getDayTime() % 24000L;
        sb.append("BUDDY: pos=").append(fmt(bp))
                .append(" health=").append((int) b.getHealth()).append('/').append((int) b.getMaxHealth())
                .append(" food=").append(b.getFood()).append("/20")
                .append(" holding=").append(itemId(b.getMainHandItem()))
                .append(" dimension=").append(level.dimension().location().getPath())
                .append(" time=").append(t < 12500 ? "day" : "night")
                .append(level.isRaining() ? " raining" : "")
                .append(" following_player=").append(b.isFollowing()).append('\n');
        sb.append("STANDING_ON: ").append(blockId(level.getBlockState(bp.below())))
                .append("  (build floor level is y=").append(bp.getY() - 1).append(", feet at y=").append(bp.getY()).append(")\n");

        sb.append("ARMOR: head=").append(itemId(b.getItemBySlot(EquipmentSlot.HEAD)))
                .append(" chest=").append(itemId(b.getItemBySlot(EquipmentSlot.CHEST)))
                .append(" legs=").append(itemId(b.getItemBySlot(EquipmentSlot.LEGS)))
                .append(" feet=").append(itemId(b.getItemBySlot(EquipmentSlot.FEET))).append('\n');

        Map<String, Integer> inv = b.summarizeInventory();
        sb.append("INVENTORY: ");
        if (inv.isEmpty()) sb.append("(empty)");
        else inv.forEach((k, v) -> sb.append(k).append(" x").append(v).append(", "));
        sb.append('\n');

        if (p != null && p.level() == level) {
            BlockPos pp = p.blockPosition();
            sb.append("PLAYER ").append(p.getName().getString()).append(": pos=").append(fmt(pp))
                    .append(" health=").append((int) p.getHealth())
                    .append(" distance=").append((int) Math.sqrt(b.distanceToSqr(p)))
                    .append(" holding=").append(itemId(p.getMainHandItem()))
                    .append(" facing=").append(p.getDirection().getName()).append('\n');
            HitResult hr = p.pick(30.0D, 1.0F, false);
            if (hr.getType() == HitResult.Type.BLOCK) {
                BlockHitResult bhr = (BlockHitResult) hr;
                sb.append("PLAYER_LOOKING_AT: ").append(blockId(level.getBlockState(bhr.getBlockPos())))
                        .append(" at ").append(fmt(bhr.getBlockPos()))
                        .append(" face=").append(bhr.getDirection().getName()).append('\n');
            }
        } else {
            sb.append("PLAYER: not in your dimension / not available\n");
        }

        // nearby entities
        List<Entity> ents = new ArrayList<>(level.getEntities(b, b.getBoundingBox().inflate(16.0D),
                e -> (e instanceof LivingEntity || e instanceof ItemEntity) && !(e instanceof Player)));
        ents.sort((x, y) -> Double.compare(b.distanceToSqr(x), b.distanceToSqr(y)));
        sb.append("NEARBY_ENTITIES: ");
        if (ents.isEmpty()) sb.append("none");
        int n = 0;
        for (Entity e : ents) {
            if (n++ >= 12) break;
            if (e instanceof ItemEntity ie) {
                sb.append("item:").append(itemId(ie.getItem())).append(" x").append(ie.getItem().getCount());
            } else {
                sb.append(BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath());
            }
            sb.append('@').append(fmt(e.blockPosition())).append("; ");
        }
        sb.append('\n');

        // nearby blocks
        int r = AiBuddyConfig.SCAN_RADIUS.get();
        int vr = Math.min(r, 10);
        Map<Block, int[]> map = new HashMap<>();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        BlockPos.MutableBlockPos tmp = new BlockPos.MutableBlockPos();
        boolean fair = AiBuddyConfig.FAIR_VISION.get();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -vr; dy <= vr; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    mp.set(bp.getX() + dx, bp.getY() + dy, bp.getZ() + dz);
                    if (!level.isLoaded(mp)) continue;
                    BlockState st = level.getBlockState(mp);
                    if (st.isAir()) continue;
                    if (fair && !exposed(level, mp, tmp)) continue; // no x-ray: hidden blocks aren't reported
                    int d2 = dx * dx + dy * dy + dz * dz;
                    int[] e = map.get(st.getBlock());
                    if (e == null) {
                        map.put(st.getBlock(), new int[] {1, d2, mp.getX(), mp.getY(), mp.getZ()});
                    } else {
                        e[0]++;
                        if (d2 < e[1]) { e[1] = d2; e[2] = mp.getX(); e[3] = mp.getY(); e[4] = mp.getZ(); }
                    }
                }
            }
        }
        List<Map.Entry<Block, int[]>> list = new ArrayList<>(map.entrySet());
        list.sort((x, y) -> Long.compare(score(y), score(x)));
        sb.append("BLOCKS_NEARBY (id count nearest@x,y,z): ");
        n = 0;
        for (Map.Entry<Block, int[]> en : list) {
            if (n++ >= 25) break;
            int[] v = en.getValue();
            sb.append(BuiltInRegistries.BLOCK.getKey(en.getKey()).getPath()).append(' ').append(v[0])
                    .append(" @").append(v[2]).append(',').append(v[3]).append(',').append(v[4]).append("; ");
        }
        sb.append('\n');
        return sb.toString();
    }

    private static boolean exposed(Level level, BlockPos.MutableBlockPos mp, BlockPos.MutableBlockPos tmp) {
        for (Direction d : Direction.values()) {
            tmp.setWithOffset(mp, d);
            if (!level.isLoaded(tmp)) continue;
            if (level.getBlockState(tmp).getCollisionShape(level, tmp).isEmpty()) return true;
        }
        return false;
    }

    private static long score(Map.Entry<Block, int[]> e) {
        String path = BuiltInRegistries.BLOCK.getKey(e.getKey()).getPath();
        long s = e.getValue()[0];
        for (String k : INTERESTING) {
            if (path.contains(k)) { s += 1_000_000L; break; }
        }
        return s;
    }

    private static String blockId(BlockState s) {
        return BuiltInRegistries.BLOCK.getKey(s.getBlock()).getPath();
    }
}
