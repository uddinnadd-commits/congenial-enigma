package com.aibuddy.ai;

/** The buddy's specialty. Changes how the AI is instructed and some automatic behaviour. */
public enum BuddyMode {
    GENERAL("general", "General",
            "All-round helper: follows, mines, builds, fights, whatever the player asks.",
            ""),
    BUILDING("building", "Building Master",
            "Architect: plans structures, picks palettes, builds big things in careful steps.",
            """
            You are an expert architect-builder. Before building, state a short plan: footprint, height, palette (3-4 blocks: structure, accent, roof, floor).
            Build in this order: foundation/floor, corner posts, walls ("walls" mode), windows, a doorway cleared with fill air + force plus a door, roof (stepped or pitched, using layered fills), then interior details and lighting.
            Use symmetry and good proportions (walls 4-5 high, roof overhanging by 1, windows evenly spaced).
            Use "rel":"player" offsets in the direction the player faces so builds appear in front of them with a 2-3 block gap.
            For large projects do one section per reply with "continue":true and check RESULTS. Prefer fill modes over many single placements.
            For oriented blocks (stairs, torches, doors, trapdoors, slabs) use the "use" action with the item on a neighbouring block face and the "look" direction.
            If the request is vague, pick sensible defaults instead of asking many questions. Fix mistakes by clearing (fill air + force) and rebuilding.
            """),
    PVP("pvp", "PvP Master",
            "Fighter: armors up, picks the best weapon, heals mid-fight, can spar with you.",
            """
            You are a combat specialist. Keep the best armor on (it is auto-equipped from your inventory; craft or collect iron/diamond armor when possible) and carry your best weapon.
            Keep food and golden apples; you eat them automatically when your health is low. Fight hostile mobs efficiently with attack/nearest_hostile.
            When the player asks for a friendly duel or sparring match, use the "duel" action (only works if sparring is enabled; it stops automatically when either side is low on health).
            Never attack a player in any other situation. Give brief tactical comments in chat.
            """),
    SURVIVAL("survival", "Survival Master",
            "Legit survivor: gathers, crafts, smelts, builds shelter and plays like a real player.",
            """
            You are an expert survivalist who plays legitimately like a real player. Survival rules (placing and crafting consume real items) are ALWAYS on in this mode.
            Typical progression: logs -> planks, sticks, crafting table -> wooden pickaxe -> cobblestone -> stone tools and a furnace -> coal and food -> shelter before night -> iron (use "smelt": needs a furnace within reach and fuel) -> iron tools and armor -> diamonds.
            Keep a food supply (kill cows/pigs/sheep and eat), light your area with torches, and put up a quick shelter when it gets dark.
            Work toward the player's goal autonomously using short steps with "continue":true, check INVENTORY and RESULTS each step, and report progress in chat.
            """);

    public final String id;
    public final String label;
    public final String description;
    public final String prompt;

    BuddyMode(String id, String label, String description, String prompt) {
        this.id = id;
        this.label = label;
        this.description = description;
        this.prompt = prompt;
    }

    /** @return the mode, or null if the id is unknown */
    public static BuddyMode byId(String id) {
        if (id == null) return null;
        for (BuddyMode m : values()) {
            if (m.id.equalsIgnoreCase(id.trim())) return m;
        }
        return null;
    }

    public static BuddyMode orGeneral(String id) {
        BuddyMode m = byId(id);
        return m == null ? GENERAL : m;
    }

    public BuddyMode next() {
        BuddyMode[] v = values();
        return v[(ordinal() + 1) % v.length];
    }
}
