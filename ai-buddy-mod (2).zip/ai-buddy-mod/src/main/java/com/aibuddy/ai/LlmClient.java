package com.aibuddy.ai;

import com.aibuddy.AiBuddyConfig;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Talks to an LLM over HTTPS on a background thread, so the game never freezes while the AI "thinks". */
public final class LlmClient {
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "aibuddy-http");
        t.setDaemon(true);
        return t;
    });

    private LlmClient() {}

    /** history entries are {role, content}; role is "user" or "assistant". */
    public static CompletableFuture<String> chat(String system, List<String[]> history) {
        // read config on the calling (server) thread
        final boolean anthropic = AiBuddyConfig.PROVIDER.get().trim().toLowerCase(Locale.ROOT).equals("anthropic");
        String u = AiBuddyConfig.API_URL.get().trim();
        if (u.isEmpty()) {
            u = anthropic ? "https://api.anthropic.com/v1/messages" : "https://api.openai.com/v1/chat/completions";
        }
        final String url = u;
        String k = AiBuddyConfig.API_KEY.get().trim();
        if (k.isEmpty()) {
            String env = System.getenv("AIBUDDY_API_KEY");
            if (env != null) k = env.trim();
        }
        final String key = k;
        final int timeoutMs = AiBuddyConfig.TIMEOUT_SECONDS.get() * 1000;

        JsonObject body = new JsonObject();
        body.addProperty("model", AiBuddyConfig.MODEL.get());
        JsonArray msgs = new JsonArray();
        if (anthropic) {
            body.addProperty("system", system);
            body.addProperty("max_tokens", AiBuddyConfig.MAX_TOKENS.get());
        } else {
            msgs.add(message("system", system));
            String tp = AiBuddyConfig.TOKEN_PARAM.get().trim();
            if (!tp.isEmpty()) body.addProperty(tp, AiBuddyConfig.MAX_TOKENS.get());
            double temp = AiBuddyConfig.TEMPERATURE.get();
            if (temp >= 0) body.addProperty("temperature", temp);
        }
        for (String[] m : normalize(history)) msgs.add(message(m[0], m[1]));
        body.add("messages", msgs);
        final byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);

        return CompletableFuture.supplyAsync(() -> {
            try {
                return call(url, key, anthropic, payload, timeoutMs);
            } catch (Exception e) {
                throw new CompletionException(e);
            }
        }, POOL);
    }

    private static String call(String url, String key, boolean anthropic, byte[] payload, int timeoutMs) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(timeoutMs);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        if (anthropic) {
            c.setRequestProperty("x-api-key", key);
            c.setRequestProperty("anthropic-version", "2023-06-01");
        } else if (!key.isEmpty()) {
            c.setRequestProperty("Authorization", "Bearer " + key);
        }
        try (OutputStream os = c.getOutputStream()) {
            os.write(payload);
        }
        int code = c.getResponseCode();
        InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String resp = is == null ? "" : new String(is.readAllBytes(), StandardCharsets.UTF_8);
        if (code < 200 || code >= 300) {
            throw new RuntimeException("HTTP " + code + ": " + (resp.length() > 300 ? resp.substring(0, 300) : resp));
        }
        JsonObject root = JsonParser.parseString(resp).getAsJsonObject();
        if (anthropic) {
            StringBuilder sb = new StringBuilder();
            for (JsonElement el : root.getAsJsonArray("content")) {
                JsonObject o = el.getAsJsonObject();
                if (o.has("text")) sb.append(o.get("text").getAsString());
            }
            return sb.toString();
        }
        JsonElement content = root.getAsJsonArray("choices").get(0).getAsJsonObject()
                .getAsJsonObject("message").get("content");
        return content == null || content.isJsonNull() ? "" : content.getAsString();
    }

    private static JsonObject message(String role, String content) {
        JsonObject o = new JsonObject();
        o.addProperty("role", role);
        o.addProperty("content", content);
        return o;
    }

    /** Merges consecutive same-role messages and makes sure the first one is from the user. */
    private static List<String[]> normalize(List<String[]> in) {
        List<String[]> out = new ArrayList<>();
        for (String[] m : in) {
            if (out.isEmpty() && !m[0].equals("user")) continue;
            if (!out.isEmpty() && out.get(out.size() - 1)[0].equals(m[0])) {
                String[] last = out.get(out.size() - 1);
                last[1] = last[1] + "\n\n" + m[1];
            } else {
                out.add(new String[] {m[0], m[1]});
            }
        }
        return out;
    }
}
