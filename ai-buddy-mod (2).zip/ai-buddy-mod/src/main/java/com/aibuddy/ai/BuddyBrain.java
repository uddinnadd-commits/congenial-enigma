package com.aibuddy.ai;

import com.aibuddy.AiBuddyConfig;
import com.aibuddy.entity.AiBuddyEntity;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletionException;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/**
 * The "mind": builds prompts, calls the LLM asynchronously (the loading time you asked about),
 * and turns the reply into actions for the buddy.
 */
public class BuddyBrain {
    private static final String SYSTEM = """
            You are {NAME}, an AI player living inside a Minecraft Java Edition 1.20.1 world. You control a human-like character (the "buddy") and play together with the human player. You only see the world through the STATE text attached to each message. Be friendly, brief, and talk like a Minecraft player.

            Reply with ONE JSON object and nothing else (no markdown fences, no extra text):
            {"say":"short chat line","actions":[ ... ],"continue":false}

            - "say": what you tell the player in chat (under 200 characters, optional).
            - "actions": ordered list (max {MAXACTIONS}) executed one after another in the game. Use [] to just talk.
            - "continue": true if you want to be called again after ALL your actions finish (long jobs, or when you need to see results / new surroundings). false when the task is done or you are just chatting. You will get the results in the next message.

            ACTION TYPES (coordinates are integer block coordinates; add "rel":"player" or "rel":"buddy" to any action with x/y/z to make them offsets from that entity's current block position):
            {"type":"follow"}  follow the player until told otherwise
            {"type":"stay"}  stand still
            {"type":"come"}  walk to the player
            {"type":"goto","x":0,"y":64,"z":0}
            {"type":"mine","block":"oak_log","count":5}  finds the nearest such block within ~20 blocks, walks there and mines it; drops go into your inventory. "block" can be a fragment like "log" or "iron_ore".
            {"type":"break","x":0,"y":64,"z":0}  mine exactly that block (for tunnels, stairs, clearing)
            {"type":"collect"}  pick up dropped items nearby
            {"type":"place","block":"cobblestone","x":0,"y":64,"z":0}
            {"type":"fill","block":"stone_bricks","x1":0,"y1":64,"z1":0,"x2":4,"y2":68,"z2":4,"mode":"solid"}  main building tool. mode: "solid" (whole box), "hollow" (shell: walls+floor+roof), "walls" (4 side walls only), "outline" (edges only). By default only empty cells are filled; add "force":true to replace existing blocks. block "air" removes blocks (clearing).
            {"type":"craft","item":"oak_planks","count":4}
            {"type":"eat"}  or  {"type":"eat","item":"bread"}
            {"type":"equip","item":"iron_pickaxe"}  hold an item; armor items are worn (armor in your inventory is also worn automatically)
            {"type":"use","x":0,"y":64,"z":0,"face":"up","item":"oak_stairs","look":"north"}  RIGHT-CLICK a block face like a player. Without "item" it uses your hand: opens/closes doors, trapdoors, fence gates, presses buttons, flips levers. With "item" it uses that item on the block: placing a block on face F of block B puts it at B+F with correct orientation (stairs face the "look" direction, torches attach to walls), also hoe, seeds, bone meal, flint and steel. Buckets do not work.
            {"type":"smelt","item":"raw_iron","count":8}  smelt items; needs a furnace within ~12 blocks and fuel in your inventory
            {"type":"duel"}  friendly sparring with your owner, only if sparring is enabled; stops when either side is low
            {"type":"attack","target":"nearest_hostile"}  or a mob id like "zombie", "cow", "pig" (optional "count")
            {"type":"give","item":"cobblestone","count":10}  bring items to the player ("item":"all" for everything)
            {"type":"wait","ticks":40}
            {"type":"say","text":"..."}  chat in the middle of a sequence

            RULES
            - Ids are lowercase Minecraft ids without the "minecraft:" prefix (e.g. "spruce_planks").
            - Axes: +x east, -x west, +z south, -z north, +y up.
            - STATE gives the player's position, facing and the block they are looking at. When asked to build "here", "in front of me" or "there", compute coordinates from those. Plan the structure's coordinates before answering.
            - Houses: separate fills for floor, walls ("walls" mode), roof, then clear a doorway with fill air + "force":true, add windows with glass, then place "oak_door" at the LOWER door block. Orientation-dependent blocks (stairs, beds, wall torches) are placed with default orientation, so prefer full blocks.
            - In survival MODE, placing and crafting consume your inventory: mine or craft first, and check INVENTORY.
            - If RESULTS show FAILED, adapt (different block, closer spot, or tell the player). Use "continue":true with short steps when you need to look at results.
            - You get hungry: eat when food is low and you have food.
            - Never attack players, except the owner via the "duel" action when they ask for a spar. You can only do what is in the action list; if asked for something impossible, say so.
            """;

    private record Pending(UUID player, String text) {}

    private final AiBuddyEntity buddy;
    private final List<String[]> history = new ArrayList<>();
    private final Deque<Pending> pending = new ArrayDeque<>();
    private boolean busy = false;
    private boolean wantsContinue = false;
    private int autoSteps = 0;
    private int gen = 0;

    public BuddyBrain(AiBuddyEntity buddy) {
        this.buddy = buddy;
    }

    // ------------------------------------------------------------------ public API

    public void ask(ServerPlayer player, String text) {
        if (busy) {
            if (pending.size() < 3) {
                pending.add(new Pending(player.getUUID(), text));
                player.sendSystemMessage(Component.literal("(" + AiBuddyConfig.BUDDY_NAME.get() + " is still thinking, I'll get to your message next)")
                        .withStyle(ChatFormatting.GRAY));
            } else {
                player.sendSystemMessage(Component.literal("Too many messages queued, give " + AiBuddyConfig.BUDDY_NAME.get() + " a second.")
                        .withStyle(ChatFormatting.GRAY));
            }
            return;
        }
        autoSteps = 0;
        wantsContinue = false;
        dispatch(player, "PLAYER_MESSAGE from " + player.getName().getString() + ": \"" + text + "\"");
    }

    public void cancel() {
        gen++;
        wantsContinue = false;
        pending.clear();
    }

    public void clearHistory() {
        history.clear();
    }

    public void say(String msg) {
        MinecraftServer server = buddy.getServer();
        if (server == null) return;
        Component c = Component.literal("<" + AiBuddyConfig.BUDDY_NAME.get() + "> ").withStyle(ChatFormatting.AQUA)
                .append(Component.literal(msg).withStyle(ChatFormatting.WHITE));
        server.getPlayerList().broadcastSystemMessage(c, false);
    }

    /** Called every tick while the buddy has nothing queued. */
    public void tickIdle() {
        if (!wantsContinue || busy) return;
        wantsContinue = false;
        if (++autoSteps > AiBuddyConfig.MAX_AUTO_STEPS.get()) {
            say("I've done a lot of steps in a row. Tell me if you want me to keep going!");
            return;
        }
        Player owner = buddy.getBuddyOwner();
        ServerPlayer sp = owner instanceof ServerPlayer s ? s : null;
        dispatch(sp, "AUTO_CONTINUE: all of your queued actions have finished (step " + autoSteps + ").");
    }

    // ------------------------------------------------------------------ internals

    private void dispatch(ServerPlayer player, String lead) {
        MinecraftServer server = buddy.getServer();
        if (server == null) return;

        String results = buddy.drainResults();
        StringBuilder user = new StringBuilder(lead);
        if (!results.isEmpty()) user.append("\nRESULTS OF YOUR LAST ACTIONS:\n").append(results);
        user.append("\n\n").append(Observer.observe(buddy, player));

        // old STATE blocks are bulky: keep only the first part of previous user messages
        for (String[] m : history) {
            if (m[0].equals("user")) {
                int idx = m[1].indexOf("\n\nSTATE:");
                if (idx > 0) m[1] = m[1].substring(0, idx);
            }
        }
        history.add(new String[] {"user", user.toString()});
        trim();

        busy = true;
        buddy.setThinking(true);
        final int myGen = gen;
        final UUID pid = player == null ? null : player.getUUID();
        final String system = SYSTEM.replace("{NAME}", AiBuddyConfig.BUDDY_NAME.get())
                .replace("{MAXACTIONS}", String.valueOf(AiBuddyConfig.MAX_ACTIONS.get()))
                + modeBlock()
                + (AiBuddyConfig.EXTRA_PROMPT.get().isBlank() ? "" : "\nEXTRA INSTRUCTIONS FROM THE SERVER OWNER:\n" + AiBuddyConfig.EXTRA_PROMPT.get());
        final List<String[]> snapshot = new ArrayList<>();
        for (String[] m : history) snapshot.add(new String[] {m[0], m[1]});

        try {
            LlmClient.chat(system, snapshot).whenComplete((reply, err) -> server.execute(() -> {
                busy = false;
                buddy.setThinking(false);
                if (buddy.isRemoved()) return;
                ServerPlayer p = pid == null ? null : server.getPlayerList().getPlayer(pid);
                if (myGen != gen) return; // cancelled with /ai stop
                if (err != null) onError(p, err);
                else onReply(p, reply);
                drainPending(server);
            }));
        } catch (Exception e) {
            busy = false;
            buddy.setThinking(false);
            onError(player, e);
        }
    }

    private String modeBlock() {
        BuddyMode m = buddy.getMode();
        StringBuilder sb = new StringBuilder("\nACTIVE MODE: ").append(m.label).append('\n');
        if (!m.prompt.isBlank()) sb.append(m.prompt).append('\n');
        sb.append("\nACTIVE RULES (enforced by the game, plan around them):\n");
        if (buddy.isSurvivalRules()) sb.append("- Placing blocks and crafting consume real items from your inventory.\n");
        if (AiBuddyConfig.CORRECT_TOOLS.get()) sb.append("- Stone, ores and similar blocks only drop items when mined with the right tool.\n");
        if (AiBuddyConfig.TOOL_DURABILITY.get()) sb.append("- Tools and weapons wear out and break; keep spares.\n");
        if (AiBuddyConfig.FAIR_VISION.get()) sb.append("- You can only see blocks that touch air or water. Ores inside rock are hidden: explore, or dig tunnels with \"break\".\n");
        if (AiBuddyConfig.CRAFT_TABLE.get()) sb.append("- Recipes bigger than 2x2 need a crafting table within 5 blocks.\n");
        if (AiBuddyConfig.NEEDS_SUPPORT.get()) sb.append("- Blocks can only be placed next to an existing block: build from the ground up, no floating blocks.\n");
        if (!AiBuddyConfig.TELEPORT_FALLBACK.get()) sb.append("- You cannot teleport. If you get stuck, find another route.\n");
        if (AiBuddyConfig.ALLOW_DUELS.get()) sb.append("- Sparring duels with the owner are enabled.\n");
        return sb.toString();
    }

    private void drainPending(MinecraftServer server) {
        if (busy) return;
        Pending next = pending.poll();
        if (next == null) return;
        ServerPlayer p = server.getPlayerList().getPlayer(next.player());
        if (p != null) ask(p, next.text());
    }

    private void onError(ServerPlayer p, Throwable err) {
        Throwable t = err instanceof CompletionException && err.getCause() != null ? err.getCause() : err;
        if (!history.isEmpty() && history.get(history.size() - 1)[0].equals("user")) history.remove(history.size() - 1);
        String msg = "My connection to the AI failed: " + t.getMessage() + " (check config/aibuddy-common.toml)";
        if (p != null) p.sendSystemMessage(Component.literal(msg).withStyle(ChatFormatting.RED));
        else say(msg);
        wantsContinue = false;
    }

    private void onReply(ServerPlayer p, String raw) {
        String text = raw == null ? "" : raw.trim();
        JsonObject obj = extractJson(text);
        String say;
        JsonArray acts = null;
        boolean cont = false;
        if (obj != null) {
            say = obj.has("say") && !obj.get("say").isJsonNull() ? obj.get("say").getAsString() : "";
            if (obj.has("actions") && obj.get("actions").isJsonArray()) acts = obj.getAsJsonArray("actions");
            cont = obj.has("continue") && !obj.get("continue").isJsonNull() && obj.get("continue").getAsBoolean();
        } else {
            say = text; // model answered in plain text, just chat it
        }
        history.add(new String[] {"assistant", obj != null ? obj.toString() : text});
        trim();

        if (!say.isBlank()) say(say.length() > 300 ? say.substring(0, 300) : say);

        boolean hadErrors = false;
        if (acts != null && acts.size() > 0) {
            List<String> errs = new ArrayList<>();
            List<Actions.Action> list = Actions.parseAll(acts, buddy, p, errs);
            for (String e : errs) buddy.addResult("PARSE ERROR: " + e);
            hadErrors = !errs.isEmpty();
            if (!list.isEmpty()) buddy.setPlan(list);
        }
        wantsContinue = cont && (!buddy.isIdle() || hadErrors);
    }

    private void trim() {
        int max = AiBuddyConfig.HISTORY.get();
        while (history.size() > max) history.remove(0);
        while (!history.isEmpty() && !history.get(0)[0].equals("user")) history.remove(0);
    }

    private static JsonObject extractJson(String text) {
        int s = text.indexOf('{');
        int e = text.lastIndexOf('}');
        if (s < 0 || e <= s) return null;
        try {
            JsonElement el = JsonParser.parseString(text.substring(s, e + 1));
            return el.isJsonObject() ? el.getAsJsonObject() : null;
        } catch (Exception ex) {
            return null;
        }
    }
}
