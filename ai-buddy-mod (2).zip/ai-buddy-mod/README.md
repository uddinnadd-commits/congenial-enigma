# AI Buddy (Forge 1.20.1)

Puts an AI model into Minecraft as a player-like buddy you can talk to. It can walk, follow you,
mine, craft, eat, fight, pick up items, hand you things, and build (fill walls/floors/roofs, place blocks, doors).

Each message takes a moment: the mod sends the situation (your position, what you're looking at, the buddy's
inventory, nearby blocks and mobs) to an AI over the internet on a background thread, so the game never freezes.
The buddy's name shows "(thinking...)" while it waits. No website of your own is needed.

## Build it on GitHub
1. Extract this zip.
2. Upload the CONTENTS to the root of a new GitHub repo, so you see `build.gradle`, `settings.gradle`, `src/` and `.github/` at the top level.
   (The workflow must be at `.github/workflows/build.yml`. The workflow can also auto-extract a zip if only the zip got uploaded.)
3. Actions tab -> "Build AI Buddy mod" -> open the run -> download the `ai-buddy-mod-jar` artifact.
4. Put the jar in `mods/` (Forge 1.20.1, 47.x).

## Connect an AI
**Easy way:** title screen -> Mods -> AI Buddy -> **Config**. Three tabs: *Connection* (provider, URL, API key, model),
*Mode* and *Fair Play*. Press Save. (The key is stored as plain text in `config/aibuddy-common.toml`, so never share that file.
On a dedicated server there is no GUI: edit the toml on the server.)

Or edit `config/aibuddy-common.toml` by hand:

| Provider | provider | apiUrl | model |
|---|---|---|---|
| OpenAI | openai | (leave empty) | gpt-4o-mini |
| Anthropic | anthropic | (leave empty) | claude-sonnet-5-5 |
| OpenRouter | openai | https://openrouter.ai/api/v1/chat/completions | any model id |
| Ollama (free, local) | openai | http://localhost:11434/v1/chat/completions | llama3.1 |

Put your key in `apiKey` (or the env var `AIBUDDY_API_KEY`). Local servers need no key.
Bigger models plan builds much better than tiny ones. Newer OpenAI models may need `tokenParam = "max_completion_tokens"`.

## Playing
- `/ai spawn` (or the AI Buddy spawn egg), then talk: `@ai follow me`, `@ai get 10 oak logs`, `@ai build a 7x7 stone brick house in front of me`
- `/ai ask <message>`, `/ai come`, `/ai stop`, `/ai status`, `/ai forget`, `/ai dismiss`
- Right-click the buddy with an item to give it; right-click empty-handed to see its inventory.
- Config switches: `requireMaterials` (survival building vs free building), `hunger`, `autoDefend`, `teleportWhenStuck`, build speed and limits.

## Modes
Set the default in the Config screen, or per buddy with `/ai mode general|building|pvp|survival`.
- **Building Master**: plans footprint + palette, builds floor/walls/roof/doors/lighting section by section.
- **PvP Master**: always wears the best armor, picks the best weapon, heals with golden apples/food mid-fight, wider defense range, can spar with you (`allowDuels`, off by default, follows the server's PvP setting).
- **Survival Master**: plays like a real player (real materials always required): wood -> tools -> furnace/smelting -> shelter -> iron -> armor, working autonomously in steps.

## Fair play (no cheating)
Each switch is in the Config screen (Fair Play tab) and in `aibuddy-common.toml`: real materials, correct tools only,
tools wear out, no x-ray (only blocks touching air/water are seen or mined), crafting table needed for 3x3 recipes,
blocks need support (no floating blocks), no teleporting when stuck. The Fair Play tab has "All fair-play ON".
The AI is told which rules are active so it plans around them.

## New abilities
- **Right-click** (`use` action): doors, trapdoors, fence gates, buttons, levers; or an item on a block (stairs/torches with correct orientation, seeds, hoe, bone meal, flint and steel). Buckets and shields are not supported.
- **Armor**: armor in the buddy's inventory is worn automatically (and rendered); give it armor by right-clicking it, or have it craft/smelt its own.
- **Smelting** (`smelt` action): needs a furnace nearby and fuel in the inventory.

## Limits
Buddy tools don't wear out. Stairs/doors/beds use default orientation. Big builds depend on how well the AI plans coordinates.
Every message costs API tokens (or local compute), and any player on a server can talk to their own buddy.
